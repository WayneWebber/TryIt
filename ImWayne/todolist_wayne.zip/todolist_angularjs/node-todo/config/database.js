module.exports = {

	// the database url to connect
	// url : 'mongodb://node:node@mongo.onmodulus.net:27017/uwO3mypu'
	url : 'mongodb://127.0.0.1:27017/waynetest'

}